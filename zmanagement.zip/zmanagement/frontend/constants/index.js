export const userMenu = [{
  label: '用户信息',
  icon: 'el-icon-star-on',
  route: 'index'
}, {
  label: '商品管理',
  icon: 'el-icon-goods',
  route: 'products'
}]

export const adminMenu = [{
  label: '用户信息',
  icon: 'el-icon-star-on',
  route: 'index'
}, {
  label: '商品管理',
  icon: 'el-icon-goods',
  route: 'products'
}, {
  label: '商家管理',
  icon: 'el-icon-menu',
  route: 'shops'
}]