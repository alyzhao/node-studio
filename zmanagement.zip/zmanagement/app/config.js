module.exports = {
  mongoDB: {
    user: 'Allen',
    password: 'Optimism*03',
    host: '127.0.0.1',
    port: 27017
  }
}