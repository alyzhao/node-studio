export default {
  mongoDB: {
    host: '139.224.118.14',
    port: '27017',
    user: 'admin',
    password: 'Optimism*03',
    db: 'jewelry'
  }
}